$(document).ready(function(){

  // Trigger by scrolling using Waypoints from http://imakewebthings.com/waypoints/

  // Hide animated elements
  $('.animated').css('opacity', 0);

  // Set navigation waypoints

  $("#home").waypoint({
    handler: function(direction) {
      if (direction == 'up') {
        $(".navbar-default").removeClass("stuck animated slideOutUp")
      }
    }, offset: '-25%'
  });

  $("#home").waypoint({
    handler: function(direction) {
      if (direction == 'down') {
        $(".navbar-default").removeClass("slideOutUp").addClass("stuck animated slideInDown")

      } else {
        $(".navbar-default").removeClass("slideInDown").addClass("slideOutUp")
      }
    }, offset: '-75%'
  });

  // Trigger #work animated elements
  $('#work').waypoint(function() {
      $('#work-content').addClass('fadeInLeft');
      $('#work-samples img').addClass('fadeInRightBig');
  }, { offset: '30%' });

  // Trigger #about animated elements
  $('#about').waypoint(function() {
      $('#about-content').addClass('fadeIn');
      $('.card-container-team').addClass('fadeInUp');
  }, { offset: '30%' });

  // Trigger #contact animated elements
  $('#contact').waypoint(function() {
      $('#contact-map').addClass('mapFadeIn');
      $('#contact-content').addClass('fadeIn');
      $('.card-container-contact').addClass('fadeInUp');
  }, { offset: '30%' });

  // Trigger #about animated elements
  $('#footer').waypoint(function() {
      $('.footer-col').addClass('fadeInUp');
  }, { offset: '70%' });

  // jQuery Smooth Scrolling from https://css-tricks.com/snippets/jquery/smooth-scrolling/
  $('a[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 500);
        return false;
      }
    }
  });

  // Load Google maps if HTML DOM Element that contains the map is found...
  if (document.getElementById('contact-map')){
    // Coordinates to center the map
    var myLatlng = new google.maps.LatLng(53.483764824297495,-2.23698782920837);
    var mapOptions = {
        zoom: 16,
        center: myLatlng,
        backgroundColor: 'none',
        draggable: false,
        scrollwheel: false,
        navigationControl: false,
        mapTypeControl: false,
        scaleControl: false,
        draggable: false,
        disableDefaultUI: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById("contact-map"), mapOptions);
    // Hide businesses
    var noPoi = [
      {
        featureType: "poi",
        stylers: [
          { visibility: "off" }
        ]
      }
    ];

    map.setOptions({styles: noPoi});
  }

  // Contact form submit
  $("#contact-form").on('submit',function(e){
      e.preventDefault();
      $("#contact-form").addClass("card-flipped");
  });

});
